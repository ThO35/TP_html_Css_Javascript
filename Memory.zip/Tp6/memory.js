class MemoryGame {
    constructor(images, blank) {
        this.images = images;
        this.blank = blank;
        this.position = shuffleCards(images.length);
        this.selection = -1;
        this.old = -1;
        this.old2 = -1;
    }
  
    build(div) {
        for (let i = 0; i < this.position.length; i++) {
            let element = document.createElement("div");
            let image = document.createElement("img");
            image.src = this.blank;
            element.onclick = () => this.click(image, i);
            div.appendChild(element);
            element.appendChild(image);
        }
    }

    click(image, i) {
        if (this.position[i] == -1) {
            return;}
      
        if (this.selection == -1) {
            image.src = this.images[this.position[i]];
            this.selection = i;}
       
	   
        else {
            if (this.selection == i) {
                return;}
			image.src = this.images[this.position[i]];
            this.old = this.selection;
            this.old2 = i;

            if (this.images[this.position[this.old]] === this.images[this.position[this.old2]]) {
                this.position[this.old] = -1;
                this.position[this.old2] = -1;
                this.selection = -1;
                this.old = -1;
                this.old2 = -1;}
				
            else {
                setTimeout(() => {
                    image.src = this.blank;
                    let oldImage = document.getElementsByTagName("img")[this.old];
                    oldImage.src = this.blank;
                    this.selection = -1;
                    this.old = -1;
                    this.old2 = -1;
                }, 1000);}}}}

const shuffleCards = function(length) {
    let cards = [];
    for(let i = 0; i < length; i++) {
        cards.push(i);
        cards.push(i);
    }
    cards.sort(() => Math.random() - 0.5);
    return cards;
};

