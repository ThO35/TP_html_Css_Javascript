"use strict";

const ajax = new XMLHttpRequest();

const appel = function (url, callback) {
  const ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4) {
      if (ajax.status == 200){
        const m = ajax.responseText;
        const ObjetJavasccript = JSON.parse(m);
        callback(ObjetJavasccript);
      } else {
        console.log("Erreur : " + ajax.status);
      }
    }
  };
  ajax.open("GET", url, true);
  ajax.overrideMimeType("application/json");
  ajax.send();
};


const write = function (fruitQuantities, prices) {
  const table2 = document.querySelector("#basket2");
  const tr = document.createElement("tr");
  const td = document.createElement("td");
  const td1 = document.createElement("td");
  const td2 = document.createElement("td");
  const td3 = document.createElement("td");
  const ligne = document.createElement("thead");
  const titre = document.createElement("th");
  td.textContent = "Fruits";
  td1.textContent = "Quantites";
  td2.textContent = "Prix";
  td3.textContent = "Total";
  tr.appendChild(td);
  tr.appendChild(td1);
  tr.appendChild(td2);
  tr.appendChild(td3);
  ligne.appendChild(tr);
  table2.appendChild(ligne);

  let tour = 0;
  let totalfruit = 0;
  let totalprix= 0;
  for (let i of Object.keys(fruitQuantities)) {
    const tr = document.createElement("tr");
    const td1 = document.createElement("td");
    const td2 = document.createElement("td");
	const td3 = document.createElement("td");
	const td4 = document.createElement("td");
    const body = document.createElement("tbody");
    td1.textContent = i;
    td2.textContent = fruitQuantities[i]
	td3.textContent =  prices[i];
	td4.textContent = fruitQuantities[i] * prices[i];
    totalfruit += fruitQuantities[i];
	totalprix+= fruitQuantities[i] * prices[i];
    tr.appendChild(td1);
    tr.appendChild(td2);
	tr.appendChild(td3);
    tr.appendChild(td4);
    body.appendChild(tr);
    table2.appendChild(body);
    tour += 1;
	
  }
  const texte = document.querySelector("#quantity");
  texte.textContent = totalfruit;
  const texte2 = document.querySelector("#price");
  texte2.textContent = totalprix;
};

appel("http://localhost:8080/fruitQuantities.json", function(fruitQuantities) {
  appel("http://localhost:8080/prices.json", function(prices) {
    write(fruitQuantities, prices);
  });
});
