"use strict";
const ajax = new XMLHttpRequest();
/**ajax.onreadystatechange = function() {
  console.log("c'est bon");};
ajax.open ("Get","https://vincentjuge1987.github.io/td/src/td08/fruitQuantities.json", true);
ajax.overrideMimeType("application/json");
ajax.send();**/


ajax.onreadystatechange = function(){
	if ((ajax.readyState == 	4  && ajax.status == 200)) {
		const m = ajax.responseText;
		const ObjetJavasccript = JSON.parse(m);
		const table = Object.keys (ObjetJavasccript);
		console.log (ObjetJavasccript);
		console.log(table);
		write(table,ObjetJavasccript);
		
		}
	else {
		console.log("eror" + ajax.status);}};
		
ajax.open("GET", "http://localhost:8080/fruitQuantities.json.", true);
ajax.overrideMimeType("application/json");

ajax.send();


const write =  function (table,ObjetJavasccript){ 
	
	const  table2= document.querySelector ("#basket");
	const tr = document.createElement("tr");
	const td = document.createElement("td");
	const td1 = document.createElement("td");
	const ligne =  document.createElement("thead");
	const titre = document.createElement ("th");
		td.textContent = "Fruits";
		td1.textContent = "Quantites";
		tr.appendChild(td);
		tr.appendChild(td1);
		ligne.appendChild(tr);
		table2.appendChild(ligne);
	
	
	let tour = 0;
	let total = 0. 
	for (let i of table){
		const tr = document.createElement("tr");
		const td1 = document.createElement("td");
		const td2 = document.createElement("td");
		const body = document.createElement("tbody");
		td1.textContent = i;
		td2.textContent =ObjetJavasccript[i];
		total+=ObjetJavasccript[i];
		tr.appendChild(td1);
		tr.appendChild(td2);
		body.appendChild(tr);
		table2.appendChild(body);
		tour +=1;};
		
		const texte = document.querySelector ("#quantity");	
		texte.textContent=total;
;}


